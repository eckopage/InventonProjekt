
namespace Inventon.DAL.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class ZamowienieTable
    {
        public ZamowienieTable()
        {
            this.ProduktZamowienieTable = new HashSet<ProduktZamowienieTable>();
        }
    
        public int id { get; set; }
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public string KodPocztowy { get; set; }
        public string Miejscowosc { get; set; }
        public string Adres { get; set; }
        public string Telefon { get; set; }
        public string Email { get; set; }
        public int StatusZamowieniaId { get; set; }
        public System.DateTime DataPrzyjecia { get; set; }
    
        public virtual ICollection<ProduktZamowienieTable> ProduktZamowienieTable { get; set; }
        public virtual StatusZamowieniaTable StatusZamowieniaTable { get; set; }
    }
}
