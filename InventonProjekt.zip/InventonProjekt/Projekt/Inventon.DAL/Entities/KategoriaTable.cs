
namespace Inventon.DAL.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class KategoriaTable
    {
        public KategoriaTable()
        {
            this.ProduktTable = new HashSet<ProduktTable>();
        }
    
        public int id { get; set; }
        public string KategoriaNazwa { get; set; }
        public string KategoriaOpis { get; set; }
        public System.DateTime KategoriaDataDodania { get; set; }
    
        public virtual ICollection<ProduktTable> ProduktTable { get; set; }
    }
}
