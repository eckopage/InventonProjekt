
namespace Inventon.DAL.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class StatusZamowieniaTable
    {
        public StatusZamowieniaTable()
        {
            this.ZamowienieTable = new HashSet<ZamowienieTable>();
        }
    
        public int id { get; set; }
        public string StatusNazwa { get; set; }
        public string StatusOpis { get; set; }
    
        public virtual ICollection<ZamowienieTable> ZamowienieTable { get; set; }
    }
}
