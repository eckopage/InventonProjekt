﻿
namespace Inventon.DAL.Entities
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Infrastructure;
    using System.Data.Objects;
    using System.Data.Objects.DataClasses;
    using System.Linq;
    
    public partial class InventonDatabaseEntities : DbContext
    {
        public InventonDatabaseEntities()
            : base("name=InventonDatabaseEntities")
        {
        }
    
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

        }
    
        public DbSet<KategoriaTable> KategoriaTable { get; set; }
        public DbSet<ProducentTable> ProducentTable { get; set; }
        public DbSet<ProduktTable> ProduktTable { get; set; }
        public DbSet<ProduktZamowienieTable> ProduktZamowienieTable { get; set; }
        public DbSet<StatusZamowieniaTable> StatusZamowieniaTable { get; set; }
        public DbSet<ZamowienieTable> ZamowienieTable { get; set; }
    
        public virtual ObjectResult<GroupCategoryWithProducts_Result> GroupCategoryWithProducts()
        {
            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<GroupCategoryWithProducts_Result>("GroupCategoryWithProducts");
        }
    }
}
