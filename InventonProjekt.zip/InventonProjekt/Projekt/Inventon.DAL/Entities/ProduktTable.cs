
namespace Inventon.DAL.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class ProduktTable
    {
        public ProduktTable()
        {
            this.ProduktZamowienieTable = new HashSet<ProduktZamowienieTable>();
        }
    
        public int id { get; set; }
        public string ProduktNazwa { get; set; }
        public string ProduktOpis { get; set; }
        public string ProduktCena { get; set; }
        public Nullable<System.DateTime> ProduktDataDodania { get; set; }
        public int ProduktProducentId { get; set; }
        public int KategoriaId { get; set; }
    
        public virtual KategoriaTable KategoriaTable { get; set; }
        public virtual ProducentTable ProducentTable { get; set; }
        public virtual ICollection<ProduktZamowienieTable> ProduktZamowienieTable { get; set; }
    }
}
