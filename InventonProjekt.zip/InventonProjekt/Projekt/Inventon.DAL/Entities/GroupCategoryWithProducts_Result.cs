
namespace Inventon.DAL.Entities
{
    using System;
    
    public partial class GroupCategoryWithProducts_Result
    {
        public string KategoriaNazwa { get; set; }
        public Nullable<int> CountedProduct { get; set; }
    }
}
