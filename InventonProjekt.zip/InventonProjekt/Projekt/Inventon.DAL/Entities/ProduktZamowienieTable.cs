
namespace Inventon.DAL.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class ProduktZamowienieTable
    {
        public int id { get; set; }
        public int ZamowienieId { get; set; }
        public int ProduktId { get; set; }
        public int Ilosc { get; set; }
        public string CenaSuma { get; set; }
    
        public virtual ProduktTable ProduktTable { get; set; }
        public virtual ZamowienieTable ZamowienieTable { get; set; }
    }
}
