
namespace Inventon.DAL.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class ProducentTable
    {
        public ProducentTable()
        {
            this.ProduktTable = new HashSet<ProduktTable>();
        }
    
        public int id { get; set; }
        public string ProducentNazwa { get; set; }
    
        public virtual ICollection<ProduktTable> ProduktTable { get; set; }
    }
}
