namespace Inventon.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class procedurka : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.ProduktTables", "Obrazek");
        }
        
        public override void Down()
        {
            AddColumn("dbo.ProduktTables", "Obrazek", c => c.Binary(storeType: "image"));
        }
    }
}
