﻿
using System.Collections.Generic;
using Inventon.DAL.Entities;
using InventonAplikacja.Models.HelpModels;

namespace InventonAplikacja.Repository.Interfaces
{
    public interface ICategory
    {
        /// <summary>
        /// Get all category
        /// </summary>
        /// <returns>Returns category list</returns>
        IEnumerable<KategoriaTable> GetAllCategory();

        /// <summary>
        /// Get groupped category list with counted products
        /// </summary>
        /// <returns>Return list of grouuper category with products</returns>
        IList<CategoryProductModel> GetCategoryWIthItems();
    }
}
