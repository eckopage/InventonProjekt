﻿namespace InventonAplikacja.Repository.Services
{
    using System.Collections.Generic;
    using System.Linq;
    using Inventon.DAL.Entities;
    using Models.HelpModels;
    using Interfaces;

    public class CategoryService:ICategory
    {
        public IEnumerable<KategoriaTable> GetAllCategory()
        {
            IList<KategoriaTable> result;
            using (var context = new InventonDatabaseEntities())
            {
                result = context.KategoriaTable.ToList();
            }
            return result;
        }

        public IList<CategoryProductModel> GetCategoryWIthItems()
        {
            using (var context = new InventonDatabaseEntities())
            {
                return context.KategoriaTable.GroupJoin(context.ProduktTable, k => k.id, p => p.KategoriaId,
                    (k, g) => new CategoryProductModel
                    {
                        CategoryName = k.KategoriaNazwa,
                        ProductCount = g.Count()
                    }).ToList();
            }
        }
    }
}