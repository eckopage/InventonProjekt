﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventonAplikacja.Models
{
    public class ProducerModel
    {
        public int id { get; set; }
        public string ProducentNazwa { get; set; }
    }
}