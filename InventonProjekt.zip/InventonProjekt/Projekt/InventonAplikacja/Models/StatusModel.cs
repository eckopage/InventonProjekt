﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventonAplikacja.Models
{
    public class StatusModel
    {
        public int id { get; set; }
        public string StatusNazwa { get; set; }
        public string StatusOpis { get; set; }
    }
}