﻿
using System.Collections.Generic;
using Inventon.DAL.Entities;

namespace InventonAplikacja.Models.HelpModels
{
    public class CompositeModelProducts
    {
        /// <summary>
        /// Products
        /// </summary>
        public IEnumerable<ProduktTable> products { get; set; }

        /// <summary>
        /// Categories with counted products
        /// </summary>
        public IList<CategoryProductModel> categoriesProducts { get; set; }
    }
}