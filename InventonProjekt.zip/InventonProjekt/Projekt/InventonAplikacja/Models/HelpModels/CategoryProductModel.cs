﻿
namespace InventonAplikacja.Models.HelpModels
{
    /// <summary>
    /// Help model for method returns groupped 
    /// categories with counted products.
    /// </summary>
    public class CategoryProductModel
    {
        /// <summary>
        /// Category name
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// Counted products. 
        /// </summary>
        public int ProductCount { get; set; }
    }
}