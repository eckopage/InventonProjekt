﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using InventonAplikacja.Models;
using Inventon.DAL.Entities;
using InventonAplikacja.Core.Extension;

namespace InventonAplikacja.Core.Mappings
{
    public partial class MappingsDefinition
    {
        public static void InitializeEntitiesMappings()
        {
            Mapper.CreateMap<ProductModel, ProduktTable>()
                .ForMember(dest => dest.KategoriaId, q => q.MapFrom(src => src.KategoriaId))
                .ForMember(dest => dest.ProduktProducentId, q => q.MapFrom(src => src.ProduktProducentId))
                .IgnoreAllNonExisting();
            Mapper.CreateMap<ProduktTable, ProductModel>()
                .ForMember(dest => dest.KategoriaId, q => q.MapFrom(src => src.KategoriaId))
                .ForMember(dest => dest.ProduktProducentId, q => q.MapFrom(src => src.ProduktProducentId))
                .IgnoreAllNonExisting();

            Mapper.CreateMap<ProducerModel, ProducentTable>().IgnoreAllNonExisting();
            Mapper.CreateMap<ProducentTable, ProducerModel>().IgnoreAllNonExisting();

            Mapper.CreateMap<CategoryModel, KategoriaTable>().IgnoreAllNonExisting();
            Mapper.CreateMap<KategoriaTable, CategoryModel>().IgnoreAllNonExisting();

            Mapper.CreateMap<OrderModel, ZamowienieTable>().IgnoreAllNonExisting();
            Mapper.CreateMap<ZamowienieTable, OrderModel>().IgnoreAllNonExisting();

            Mapper.CreateMap<ProductOrderModel, ProduktZamowienieTable>().IgnoreAllNonExisting();
            Mapper.CreateMap<ProduktZamowienieTable, ProductOrderModel>().IgnoreAllNonExisting();

            Mapper.CreateMap<StatusModel, StatusZamowieniaTable>().IgnoreAllNonExisting();
            Mapper.CreateMap<StatusZamowieniaTable, StatusModel>().IgnoreAllNonExisting();
        }
    }
}