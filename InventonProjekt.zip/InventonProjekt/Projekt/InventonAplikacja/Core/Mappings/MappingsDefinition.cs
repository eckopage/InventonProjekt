﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventonAplikacja.Core.Mappings
{
    public static partial class MappingsDefinition
    {
        public static void Initialize()
        {
            InitializeEntitiesMappings();
        }
    }
}