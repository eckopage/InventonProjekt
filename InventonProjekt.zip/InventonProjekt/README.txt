Instalacja:

1) Robimy restore bazy danych (MSSQL 2012)
2) Otwieramy aplikacj� w VS2012.
3) Podmieniamy connectionstringi w configach w projekcie aplikacji jak i projekcie Inventon.DAL
4) Uruchamiamy aplikacj� np F5 (paczki do��czy�em do projektu, ale nuget zaci�gnie nam paczki w momencie uruchomienia debuggera).

W razie pyta� prosz� pisa� na adres: erwinczerniawski@gmail.com.
